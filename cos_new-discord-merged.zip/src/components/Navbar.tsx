"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import ThemeToggle from "@/components/ThemeToggle";
import { canAccessManagementPanel, getRoleLabel, getRoleBadgeClass } from "@/lib/roles";

export default function Navbar() {
  const pathname = usePathname();
  const { data: session } = useSession();

  let navBg = "bg-slate-900";
  if (pathname.startsWith("/vmpk")) navBg = "bg-[#E31837] text-white"; // VMPK Red
  if (pathname.startsWith("/vbp")) navBg = "bg-[#005A9C] text-white"; // VBP Blue

  const hasManagementAccess = session?.user?.role ? canAccessManagementPanel(session.user.role) : false;

  return (
    <nav className={`${navBg} text-white shadow-md transition-colors duration-300`}>
      <div className="container mx-auto px-4 py-3 flex flex-wrap justify-between items-center gap-4">
        <Link href="/" className="flex items-center group">
          <span className="text-xl font-bold font-mono tracking-wider flex items-center gap-2 text-white group-hover:text-amber-300 transition-colors">
            🚍 VZTM KIELCE
          </span>
        </Link>
        <div className="flex gap-4 md:gap-5 items-center flex-wrap">
          <Link href="/" className="text-white hover:text-amber-300 font-semibold transition-colors">Strona główna</Link>
          <Link href="/vmpk" className="text-white hover:text-yellow-300 font-semibold transition-colors">VMPK</Link>
          <Link href="/vbp" className="text-white hover:text-gray-300 font-semibold transition-colors">VBP</Link>
          <Link href="/kontakt" className="text-white hover:opacity-80 transition-opacity">Kontakt</Link>
          
          <ThemeToggle />

          {session?.user ? (
            <div className="flex items-center gap-3 bg-slate-900/80 py-1 px-3 rounded-lg border border-slate-700/80">
              <div className="flex items-center gap-2">
                {session.user.avatar ? (
                  <img
                    src={session.user.avatar}
                    alt={session.user.username}
                    className="w-7 h-7 rounded-full object-cover border-2 border-amber-400 shrink-0 shadow-xs"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-xs font-bold text-amber-400 shrink-0">
                    {session.user.username?.slice(0, 2).toUpperCase() || "👤"}
                  </div>
                )}
                <span className="text-xs text-white font-mono font-bold">
                  {session.user.username}
                  {session.user.badgeNumber && (
                    <span className="ml-1 text-[11px] text-amber-300 font-semibold">
                      [{session.user.badgeNumber}]
                    </span>
                  )}
                </span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${getRoleBadgeClass(session.user.role)}`}>
                  {getRoleLabel(session.user.role)}
                </span>
              </div>

              {hasManagementAccess && (
                <Link href="/panel/zarzad" className="bg-amber-600 hover:bg-amber-500 text-white px-2.5 py-1 rounded text-xs font-semibold transition-colors shadow">
                  Panel zarządu
                </Link>
              )}

              <Link href="/panel/kierowca" className="bg-slate-700 hover:bg-slate-600 text-white px-2.5 py-1 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs">
                {session.user.avatar && (
                  <img
                    src={session.user.avatar}
                    alt=""
                    className="w-4 h-4 rounded-full object-cover border border-amber-300 shrink-0"
                  />
                )}
                <span>Panel kierowcy</span>
              </Link>

              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="bg-red-600/80 hover:bg-red-600 text-white px-2.5 py-1 rounded text-xs font-semibold transition-colors"
                title="Wyloguj się"
              >
                Wyloguj
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">
                Logowanie
              </Link>
              <Link href="/register" className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">
                Złóż wniosek
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
